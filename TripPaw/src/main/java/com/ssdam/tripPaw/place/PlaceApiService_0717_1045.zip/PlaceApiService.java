package com.ssdam.tripPaw.place;

import com.ssdam.tripPaw.domain.Place;
import com.ssdam.tripPaw.domain.PlaceImage;
import com.ssdam.tripPaw.domain.PlaceType;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Service
public class PlaceApiService {

    private final PlaceMapper placeMapper;
    private final PlaceTypeMapper placeTypeMapper;
    private final PlaceImageMapper placeImageMapper;
    private final RestTemplate restTemplate = new RestTemplate();

    private static final String key = "bEzli6nTnVAqDCGLttEaemrA%2BSSd4Eec2q6Pq1Zc%2B7XExraEhli6YSth32uv1ghTnI0VksM2YwF%2Bawnots8hpA%3D%3D"; 

    public PlaceApiService(PlaceMapper placeMapper, PlaceTypeMapper placeTypeMapper, PlaceImageMapper placeImageMapper) {
        this.placeMapper = placeMapper;
        this.placeTypeMapper = placeTypeMapper;
        this.placeImageMapper = placeImageMapper;
    }

    private static final Map<String, String> contentTypeIdMap = Map.of(
        "12", "관광지", "14", "문화시설", "15", "축제/공연/행사",
        "25", "여행코스", "28", "레포츠", "32", "숙박",
        "38", "쇼핑", "39", "음식점"
    );

    private boolean isValidJson(String body) {
        return body != null && body.trim().startsWith("{");
    }

    public void fetchAndSavePetFriendlyPlaces() throws InterruptedException {
        int[] areaCodes = {1, 2, 3, 4, 5, 6, 7, 8, 31, 32, 33, 34, 35, 36, 37, 38, 39};
        String[] contentTypeIds = {"12", "14", "15", "25", "28", "32", "38", "39"};

        ExecutorService executor = Executors.newFixedThreadPool(3);

        for (int areaCode : areaCodes) {
            for (String contentTypeId : contentTypeIds) {
                int pageNo = 1;
                while (true) {
                    try {
                        String apiUrl = "https://apis.data.go.kr/B551011/KorPetTourService/areaBasedList"
                                + "?serviceKey=" + key
                                + "&MobileOS=ETC"
                                + "&MobileApp=TripPaw"
                                + "&areaCode=" + areaCode
                                + "&contentTypeId=" + contentTypeId
                                + "&numOfRows=30"
                                + "&pageNo=" + pageNo
                                + "&_type=json";

                        URI uri = new URI(apiUrl);
                        HttpHeaders headers = new HttpHeaders();
                        headers.add("Accept", "application/json");
                        HttpEntity<String> entity = new HttpEntity<>(headers);

                        ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
                        String responseBody = response.getBody();
                        
                        Thread.sleep(1500); // 1.5초 텀

                        if (!isValidJson(responseBody)) {
                            System.out.println("⚠️ JSON 응답이 유효하지 않음");
                            break;
                        }

                        JSONObject bodyObj = new JSONObject(responseBody).getJSONObject("response").getJSONObject("body");
                        JSONArray items = bodyObj.getJSONObject("items").getJSONArray("item");

                        for (int i = 0; i < items.length(); i++) {
                            JSONObject item = items.getJSONObject(i);
                            executor.submit(() -> {
                                try {
                                    processPlaceItem(item);
                                    Thread.sleep(1300);
                                } catch (Exception e) {
                                    System.out.println("⚠️ 처리 실패: " + e.getMessage());
                                }
                            });
                        }

                        int totalCount = bodyObj.optInt("totalCount", 0);
                        int numOfRows = bodyObj.optInt("numOfRows", 30);

                        if ((pageNo * numOfRows) >= totalCount) break;
                        pageNo++;

                    } catch (Exception e) {
                        System.out.println("❌ 전체 에러: " + e.getMessage());
                        break;
                    }
                }
            }
        }

        executor.shutdown();
        executor.awaitTermination(30, TimeUnit.MINUTES);
    }

    private void processPlaceItem(JSONObject item) throws Exception {
        long contentId = item.optLong("contentid");
        String contentTypeId = item.optString("contenttypeid");

        boolean petFriendly = false;
        String description = "";
        String openHours = "";
        String restDays = "";
        String price = "";
        String parking = "";
        String homepage = "";

        HttpHeaders headers = new HttpHeaders();
        headers.add("Accept", "application/json");
        HttpEntity<String> entity = new HttpEntity<>(headers);

        // detailCommon
        try {
            String detailUrl = "https://apis.data.go.kr/B551011/KorPetTourService/detailCommon"
                    + "?serviceKey=" + key
                    + "&MobileOS=ETC"
                    + "&MobileApp=TripPaw"
                    + "&_type=json"
                    + "&contentId=" + contentId
                    + "&contentTypeId=" + contentTypeId;

            ResponseEntity<String> detailResponse = restTemplate.exchange(new URI(detailUrl), HttpMethod.GET, entity, String.class);
            if (isValidJson(detailResponse.getBody())) {
                JSONArray detailItems = new JSONObject(detailResponse.getBody())
                        .getJSONObject("response").getJSONObject("body")
                        .getJSONObject("items").getJSONArray("item");

                if (!detailItems.isEmpty()) {
                    JSONObject detail = detailItems.getJSONObject(0);
                    homepage = detail.optString("homepage", "");
                    openHours = detail.optString("usetime", "");
                    restDays = detail.optString("restdate", "");
                    System.out.println("🧾 detail 원본:\n" + detail.toString(2));

                    String rawOverview = detail.optString("overview", "");
                    if (rawOverview.isBlank()) {
                        System.out.println("⚠️ overview는 비어 있음");
                    } else {
                        System.out.println("✅ overview 내용 (앞 100자): " + rawOverview.substring(0, Math.min(100, rawOverview.length())));
                    }

                    description = rawOverview;
                }
            }
        } catch (Exception e) {
            System.out.println("⚠️ detailCommon 파싱 실패: contentId=" + contentId);
        }

        // detailIntro
        try {
            String detailUrl = "https://apis.data.go.kr/B551011/KorPetTourService/detailIntro"
                    + "?serviceKey=" + key
                    + "&MobileOS=ETC"
                    + "&MobileApp=TripPaw"
                    + "&_type=json"
                    + "&contentId=" + contentId
                    + "&contentTypeId=" + contentTypeId;

            ResponseEntity<String> detailResponse = restTemplate.exchange(new URI(detailUrl), HttpMethod.GET, entity, String.class);
            if (isValidJson(detailResponse.getBody())) {
                JSONArray detailItems = new JSONObject(detailResponse.getBody())
                        .getJSONObject("response").getJSONObject("body")
                        .getJSONObject("items").getJSONArray("item");

                if (!detailItems.isEmpty()) {
                    JSONObject detail = detailItems.getJSONObject(0);
                    openHours = detail.optString("usetime", "");
                    restDays = detail.optString("restdate", "");
                    parking = detail.optString("parking", "");
                }
            }
        } catch (Exception e) {
            System.out.println("⚠️ detailIntro 파싱 실패: contentId=" + contentId);
        }

        // detailInfo
        try {
            String infoUrl = "https://apis.data.go.kr/B551011/KorPetTourService/detailInfo"
                    + "?serviceKey=" + key
                    + "&MobileOS=ETC"
                    + "&MobileApp=TripPaw"
                    + "&_type=json"
                    + "&contentId=" + contentId
                    + "&contentTypeId=" + contentTypeId;

            ResponseEntity<String> infoResponse = restTemplate.exchange(new URI(infoUrl), HttpMethod.GET, entity, String.class);

            if (isValidJson(infoResponse.getBody())) {
                JSONArray infoItems = new JSONObject(infoResponse.getBody())
                        .getJSONObject("response").getJSONObject("body")
                        .getJSONObject("items").getJSONArray("item");

                for (int k = 0; k < infoItems.length(); k++) {
                    JSONObject infoItem = infoItems.getJSONObject(k);
                    String infoName = infoItem.optString("infoname");
                    if (infoName.contains("입장")) price = infoItem.optString("infotext", "");
                    if (infoName.contains("주차")) parking = infoItem.optString("infotext", "");
                }
            }
        } catch (Exception e) {
            System.out.println("⚠️ detailInfo 파싱 실패: contentId=" + contentId);
        }

        // 타입 처리
        String typeName = contentTypeIdMap.getOrDefault(contentTypeId, "기타");
        PlaceType placeType = placeTypeMapper.findByName(typeName);
        if (placeType == null) {
            placeType = new PlaceType();
            placeType.setName(typeName);
            placeTypeMapper.insert(placeType);
            placeType = placeTypeMapper.findByName(typeName);
        }

        Place place = new Place();
        place.setName(item.optString("title"));
        place.setRegion(item.optString("addr1"));
        place.setLatitude(item.optString("mapy"));
        place.setLongitude(item.optString("mapx"));
        place.setHomePage(homepage);
        place.setPhone(item.optString("tel"));
        place.setImageUrl(item.optString("firstimage"));
        place.setExtermalContentId(contentId);
        place.setSource("KTO");
        place.setPetFriendly(petFriendly);
        place.setOpenHours(openHours);
        place.setRestDays(restDays);
        place.setPrice(price);
        place.setParking(parking);
        place.setDescription(description);
        place.setPlaceType(placeType);

        placeMapper.insert(place);

        // 이미지 처리
        try {
            String imageUrl = "https://apis.data.go.kr/B551011/KorService2/detailImage2"
                    + "?serviceKey=" + key
                    + "&contentId=" + contentId
                    + "&imageYN=Y"
                    + "&MobileOS=ETC"
                    + "&MobileApp=TripPaw"
                    + "&_type=json";

            ResponseEntity<String> imageResponse = restTemplate.exchange(new URI(imageUrl), HttpMethod.GET, entity, String.class);

            if (isValidJson(imageResponse.getBody())) {
                JSONArray imageItems = new JSONObject(imageResponse.getBody())
                        .getJSONObject("response").getJSONObject("body")
                        .getJSONObject("items").getJSONArray("item");

                for (int j = 0; j < imageItems.length(); j++) {
                    String originUrl = imageItems.getJSONObject(j).optString("originimgurl");
                    if (!originUrl.isBlank()) {
                        PlaceImage placeImage = new PlaceImage();
                        placeImage.setImageUrl(originUrl);
                        placeImage.setPlace(place);
                        placeImageMapper.insert(placeImage);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("⚠️ 이미지 로딩 실패: contentId=" + contentId);
        }
    }
}
