package com.ssdam.tripPaw.domain;

public enum TripStatus {
    PLANED,
    ONGOING,
    END
}
