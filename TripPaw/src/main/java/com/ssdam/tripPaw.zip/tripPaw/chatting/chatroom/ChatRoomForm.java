package com.ssdam.tripPaw.chatting.chatroom;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatRoomForm {
	private String title;
	private String description;
}
