package com.ssdam.tripPaw.member.config;

public enum ChatRole {
	  ADMIN,  // 방장
    MEMBER    // 일반 사용자
}
