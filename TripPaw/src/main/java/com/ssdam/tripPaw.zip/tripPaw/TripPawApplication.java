package com.ssdam.tripPaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripPawApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripPawApplication.class, args);
	}

}
